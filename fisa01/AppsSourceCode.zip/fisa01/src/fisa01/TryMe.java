package fisa01;

import java.util.ArrayList;
import java.util.Scanner;

public class TryMe 
{
	private ArrayList<String> routesArr = new ArrayList<String>();
	private boolean repeatCitiesAllowed;
	private TryMe tryme;
	
	public TryMe()
	{
		this.tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
	}
	
	
	public TryMe(ArrayList<String> routesArr,boolean repeatCitiesAllowed)
	{
		this.routesArr.addAll(routesArr);
		this.repeatCitiesAllowed=repeatCitiesAllowed;
	}

	public static void main(String[] args) 
	{
		System.out.println("*****************************************************************");
		System.out.println("Welcome to TRY-M (Customised Application based on DIJKSTRA ALGORITHM).");
		System.out.println("I have towns by NAME A, B,C,D,E.");
		System.out.println("I will help you to compute the answers for the following conditions:");
		System.out.println("The distance of the route A-B-C");
		System.out.println("The distance of the route A-D.");
		System.out.println("The distance of the route A-D-C.");
		System.out.println("The distance of the route A-E-B-C-D.");
		System.out.println("The distance of the route A-E-D.");
		System.out.println("The number of trips starting at C and ending at C with a maximum of 3 stops.");
		System.out.println("The number of trips starting at A and ending at C with exactly 4 stops.");
		System.out.println("The length of the shortest route (in terms of distance to travel) from A to C.");
		System.out.println("The length of the shortest route (in terms of distance to travel) from B to B.");
		System.out.println("The number of different routes from C to C with a distance of less than 30.");
		System.out.println("*****************************************************************");
		
		ArrayList<String> routesArr = new ArrayList<String>();
		Scanner sc= new Scanner(System.in); //System.in is a standard input stream
		
		
		/* Variables for storing input Data with default data--START*/
		String inpRoute= "000";
		boolean itr=true;
		boolean repeatCitiesAllowed = false;
		/* Variables for storing input Data with default data--END*/
		
		try
		{
			/* Taking of inputs--START*/
			System.out.print("Enter 1, if is allowed visiting of Cities more than once. Else enter 0:");			
			inpRoute= sc.nextLine();
			if(inpRoute.equalsIgnoreCase("1"))
				repeatCitiesAllowed = true;
			TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
			while(itr)
			{
				System.out.print("Between List of towns A-E, Enter First Route With Distance(Ex:AD9) OR enter 0 to complete the input:");			
				inpRoute= sc.nextLine();
				if(inpRoute!=null && !inpRoute.isEmpty() && inpRoute.length()>=3)
				{
					tryme.validateInput(inpRoute);
				}
				else if(inpRoute.equalsIgnoreCase("0"))
				{
					System.out.println("End of input entry.");
					itr=false;
				}
				else
				{
					System.out.println("Input value do not met the req.");
				}
			}
			sc.close();
			/* Taking of inputs--END*/
			
			tryme.testMe();
		}
		catch (Exception e) 
		{
			System.out.println("Exception occured in main method:"+e.getMessage());
		}
	}
	
	
	public String validateInput(String inpRoute)
	{
		String msg="";
		int ctrDup=0;
		try
		{
			if(inpRoute.substring(0, 1).matches("[a-eA-E]"))
				if(inpRoute.substring(1, 2).matches("[a-eA-E]"))
					if(!inpRoute.substring(0, 1).equalsIgnoreCase(inpRoute.substring(1, 2)))
						if(!inpRoute.substring(2, 3).equalsIgnoreCase("0") && inpRoute.substring(2).matches("[0-9]+"))
						{
							ctrDup=0;
							for(int m=0;m<this.routesArr.size();m++)
							{
								if(inpRoute.substring(0,2).equalsIgnoreCase(this.routesArr.get(m).substring(0,2)))
								{
									ctrDup++;
									break;
								}
							}
							if(ctrDup==0)
								this.routesArr.add(inpRoute);
							else
								msg=msg.concat("Duplicate data for "+inpRoute+".");
						}
						else
							msg=msg.concat("Input value "+inpRoute+" for Distance do not met the req.");
					else
						msg=msg.concat("Input value "+inpRoute+" for Origen and Destination town cant be same.");
				else
					msg=msg.concat("Input value "+inpRoute+" for Destination town do not met the req.");
			else
				msg=msg.concat("Input value "+inpRoute+" for Origen town do not met the req.");
			if(msg.length()>0)
			{
				System.out.println("Input value do not met the req :"+msg);
			}
			else
			{
				msg="Input OK";
				System.out.println(msg);
			}
			//System.out.println("Validation Result for inpRoute"+this.routesArr.size());
		}
		catch (Exception e) 
		{
			System.out.println("Exception occured in validateInput method:"+e.getMessage());
		}
		finally 
		{
			return msg;
		}
	}
	
	public void testMe() throws Exception
	{
		try
		{
			long strTime= System.currentTimeMillis();
			System.out.println("################################################################### START OF EVALUATION OF 10 CONDITIONS");
			if(this.routesArr.size()>0)
			{
				TryMe tryme = new TryMe(this.routesArr, this.repeatCitiesAllowed);
				
				/*Printing the input Data*/
				System.out.println("Is allowed visiting of Cities more than once?"+repeatCitiesAllowed);
				for(int x=0;x<this.routesArr.size();x++)
				{
					System.out.println("Input data["+x+"]:"+this.routesArr.get(x));
				}
				
				System.out.println("");
				tryme.getDistance("ABC");
	
				System.out.println("");
				tryme.getDistance("AD");
				
				System.out.println("");
				tryme.getDistance("ADC");
				
				System.out.println("");
				tryme.getDistance("AEBCD");
				
				System.out.println("");
				tryme.getDistance("AED");
				
				System.out.println("");
				tryme.getTripsMaxNStops("C", "C", 3);
						
				System.out.println("");
				tryme.getTripsExactNStops("A", "C", 4);
						
				System.out.println("");
				tryme.getShortestDistRoute("A","C");
						
				System.out.println("");
				tryme.getShortestDistRoute("B","B");
						
				System.out.println("");
				tryme.getCountOfRoutesWithDistLessThanN("C","C",30);
			}
			else
			{
				System.out.println("No inputs found");
			}
			System.out.println("################################################################### END OF EVALUATION OF 10 CONDITIONS");
			System.out.println("EXEC TIME:"+(System.currentTimeMillis()-strTime)+" mseconds1");
		}
		catch (Exception e) 
		{
			System.out.println("Exception occured in testMe method:"+e.getMessage());
		}
	}
	
	//Get Distance between 2 cities/towns (path)
		public int getDistance(String path)
		{
			int dist=0;
			int dist_res=0;
			try
			{
				System.out.println("======= Evaluating the distance of the route "+path+" ======");
				
				
				
				for(int x=0;x<path.length()-1;x++) // For each city(Except the last) in the path. For Eg: ABCD will get A,B and C 
				{
					dist=0;
					for(int y=0;y<this.routesArr.size();y++) // For each path in the input
					{
						if(this.routesArr.get(y).substring(0, 2).equalsIgnoreCase(path.substring(x, (x+2)))) //Validate if the AB exist in input routes
						{
							dist=Integer.parseInt(this.routesArr.get(y).substring(2)); //Get the distance in the input route. For Eg: AB9 will give 9 as distance
						}
					}
					if(dist==0)
					{
						dist_res=0;
						break;
						//return 0; //If input routes don't have sufficient routes to traverse from Origin to Destination city in the path provided.
					}
					else
						dist_res=dist_res+dist; //Add all the distances, if input routes got the routes to traverse from Origin to Destination city in the path provided.
				}
				if(dist_res==0)
					System.out.println("==========>The distance of the route "+path+": NO SUCH ROUTE");
				else
				{
					System.out.println("==========>The distance of the route "+path+":"+dist_res);
				}
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getDistance method:"+e.getMessage());
			}
			finally 
			{
				return dist_res;
			}			
		}
		
		//get paths between origin and destination cities/town
		public ArrayList<String> getPaths(ArrayList<String> pathsArr, String strDestination)
		{
			String strNextOrigen="";
			String visitedCities="";
			try
			{
				for(int j=0;j<pathsArr.size();j++) //For all the paths staring from origin city, like AB, AD and AE from city A
				{
					int ctr=1;
					while(!pathsArr.get(j).substring(pathsArr.get(j).length()-1, pathsArr.get(j).length()).equalsIgnoreCase(strDestination) && ctr!=0) //Traversing to destination city or terminating the route if no futher path found to reach the destination city.
					{
						ctr=0;
						strNextOrigen=pathsArr.get(j).substring(pathsArr.get(j).length()-1, pathsArr.get(j).length()); // If path is AB, strNextOrigen=B. If path is ABC, strNextOrigen=C
						visitedCities=pathsArr.get(j).substring(0,pathsArr.get(j).length()-1); // If path is AB, visitedCities=A. If path is ABC, visitedCities=AB
						
						//for path AB, if found only 1 next path BC=update the path AB as ABC. If found more than 1 paths like BC and BE, update the existing path AB as ABC and add new path in list as ABE.
						for(int i=0;i<this.routesArr.size();i++)
						{
							if(this.routesArr.get(i).substring(0, 1).equalsIgnoreCase(strNextOrigen))
							{
								if(!pathsArr.get(j).contains(this.routesArr.get(i).substring(0, 2)))
								{
									if(ctr==0)
										pathsArr.set(j, visitedCities.concat(this.routesArr.get(i).substring(0, 2)));
									else
										pathsArr.add(visitedCities.concat(this.routesArr.get(i).substring(0, 2)));							
									ctr++;
								}
							}
						}
					}
				}
				//Remove al the paths that started from origin city but can find route to reach destination city.For eg: If origin=A, Dest=C and paths are ABC and ABD and ABEC, then ABD will be removed from pathArr 
				for(int j=0;j<pathsArr.size();)
				{
					if(!pathsArr.get(j).substring(pathsArr.get(j).length()-1, pathsArr.get(j).length()).equalsIgnoreCase(strDestination))
					{
						pathsArr.remove(j);
					}
					else
						j++;
				}
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getPaths method:"+e.getMessage());
			}
			finally 
			{
				return pathsArr;
			}
		}
		
		//get paths between origin and destination cities/town
		public ArrayList<String> getPaths2(String strOrigen,String strDestination)
		{
			System.out.println("======= Evaluating the number of trips starting at "+strOrigen+" and ending at "+strDestination+" ======");
			ArrayList<String> pathsArr = new ArrayList<String>();
			try
			{
				/*Finding the outward paths starting from Origin City in input data*/
				for(int i=0;i<this.routesArr.size();i++)
				{
					if(this.routesArr.get(i).substring(0, 1).equalsIgnoreCase(strOrigen))
					{
						pathsArr.add(this.routesArr.get(i).substring(0, 2));
					}
				}
	
				/*Find all the traversing paths between Origin and Destination city from the input data*/
				if(pathsArr.size()!=0)
				{
					//pathsArrAC=tryme.getPaths(pathsArrAC,strDestination);
					
					
					String strNextOrigen="";
					String visitedCities="";
					for(int j=0;j<pathsArr.size();j++) //For all the paths staring from origin city, like AB, AD and AE from city A
					{
						int ctr=1;
						while(!pathsArr.get(j).substring(pathsArr.get(j).length()-1, pathsArr.get(j).length()).equalsIgnoreCase(strDestination) && ctr!=0) //Traversing to destination city or terminating the route if no futher path found to reach the destination city.
						{
							ctr=0;
							strNextOrigen=pathsArr.get(j).substring(pathsArr.get(j).length()-1, pathsArr.get(j).length()); // If path is AB, strNextOrigen=B. If path is ABC, strNextOrigen=C
							visitedCities=pathsArr.get(j).substring(0,pathsArr.get(j).length()-1); // If path is AB, visitedCities=A. If path is ABC, visitedCities=AB
							
							//for path AB, if found only 1 next path BC=update the path AB as ABC. If found more than 1 paths like BC and BE, update the existing path AB as ABC and add new path in list as ABE.
							for(int i=0;i<this.routesArr.size();i++)
							{
								if(this.routesArr.get(i).substring(0, 1).equalsIgnoreCase(strNextOrigen))
								{
									if(!pathsArr.get(j).contains(this.routesArr.get(i).substring(0, 2)))
									{
										if(ctr==0)
											pathsArr.set(j, visitedCities.concat(this.routesArr.get(i).substring(0, 2)));
										else
											pathsArr.add(visitedCities.concat(this.routesArr.get(i).substring(0, 2)));							
										ctr++;
									}
								}
							}
						}
					}
					//Remove al the paths that started from origin city but can find route to reach destination city.For eg: If origin=A, Dest=C and paths are ABC and ABD and ABEC, then ABD will be removed from pathArr 
					for(int j=0;j<pathsArr.size();)
					{
						if(!pathsArr.get(j).substring(pathsArr.get(j).length()-1, pathsArr.get(j).length()).equalsIgnoreCase(strDestination))
						{
							pathsArr.remove(j);
						}
						else
							j++;
					}
					
					
					System.out.println("The number of trips starting at "+strOrigen+" and ending at "+strDestination+":"+pathsArr.size());
					
					for(int i=0;i<pathsArr.size();i++)
						System.out.println("Trip starting at "+strOrigen+" and ending at "+strDestination+":"+pathsArr.get(i));
				}
				else
					System.out.println("The number of trips starting at "+strOrigen+" and ending at "+strDestination+": 0");
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getPaths2 method:"+e.getMessage());
			}
			finally 
			{
				return pathsArr;
			}
		}
		
		public int getTripsMaxNStops(String strOrigen,String strDestination,int stops)
		{
			System.out.println("======= Evaluating the number of trips starting at "+strOrigen+" and ending at "+strDestination+" with a maximum of "+stops+" stops ======");
			ArrayList<String> pathsArr = new ArrayList<String>();
			ArrayList<String> pathsArr2 = new ArrayList<String>();
			try
			{
				TryMe tryme = new TryMe(this.routesArr, this.repeatCitiesAllowed);
				pathsArr2 = tryme.getPaths2(strOrigen, strDestination);
				pathsArr.addAll(pathsArr2);
				if(this.repeatCitiesAllowed)
				{
					System.out.println("Considering route to repeated cities");
					for(int x=0;x<pathsArr.size();x++) //For each path from C-C
					{
						for(int y=0;y<pathsArr2.size();y++) //For each path from C-C
						{
							if(pathsArr.get(x).length()+pathsArr2.get(y).length()<=(stops+2)) //Validate if adding the path still obeys the condition (maximum of 3 stops)
							{
								pathsArr.add(pathsArr.get(x).concat(pathsArr2.get(y).substring(1)));
							}
						}						
					}
				}
				for(int i=0;i<pathsArr.size();)
				{
					if(pathsArr.get(i).length()>(stops+1))
						pathsArr.remove(i);
					else
						i++;
				}
				System.out.println("==========>The number of trips starting at "+strOrigen+" and ending at "+strDestination+" with a maximum of "+stops+" stops:"+pathsArr.size());
				for(int i=0;i<pathsArr.size();i++)
					System.out.println("==========>Trip starting at "+strOrigen+" and ending at "+strDestination+" with a maximum of "+stops+" stops:"+pathsArr.get(i));
				//return pathsArr.size();
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getTripsMaxNStops method:"+e.getMessage());
			}
			finally 
			{
				return pathsArr.size();
			}
		}
		
		public int getTripsExactNStops(String strOrigen,String strDestination,int stops)
		{
			System.out.println("======= Evaluating the number of trips starting at "+strOrigen+" and ending at "+strDestination+" with exactly "+stops+" stops ======");
			ArrayList<String> pathsArr = new ArrayList<String>();
			ArrayList<String> pathsArr2 = new ArrayList<String>();
			try
			{
				TryMe tryme = new TryMe(this.routesArr, this.repeatCitiesAllowed);
				pathsArr=tryme.getPaths2(strOrigen, strDestination);
				pathsArr2=tryme.getPaths2(strDestination, strDestination);
				
				if(this.repeatCitiesAllowed)
				{
					System.out.println("Considering route to repeated cities");
					for(int x=0;x<pathsArr.size();x++) //For each path from A-C
					{
						for(int y=0;y<pathsArr2.size();y++) //For each path from A-C
						{
							if(pathsArr.get(x).length()+pathsArr2.get(y).length()==(stops+2)) //Validate if adding the path still obeys the condition (exactly 4 stops). For eg: ABC and CDC form ABCDC
							{
								pathsArr.add(pathsArr.get(x).concat(pathsArr2.get(y).substring(1)));
							}
						}						
					}
				}
				for(int i=0;i<pathsArr.size();)
				{
					if(pathsArr.get(i).length()!=(stops+1))
						pathsArr.remove(i);
					else
						i++;
				}
				System.out.println("==========>The number of trips starting at "+strOrigen+" and ending at "+strDestination+" with exactly "+stops+" stops:"+pathsArr.size());
				for(int i=0;i<pathsArr.size();i++)
					System.out.println("==========>Trip starting at "+strOrigen+" and ending at "+strDestination+" with exactly "+stops+" stops:"+pathsArr.get(i));
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getTripsExactNStops method:"+e.getMessage());
			}
			finally 
			{
				return pathsArr.size();
			}
		}
		
		public int getShortestDistRoute(String strOrigen,String strDestination)
		{
			System.out.println("======= Evaluating the length of the shortest route (in terms of distance to travel) from "+strOrigen+" to "+strDestination+" ======");
			ArrayList<String> pathsArr = new ArrayList<String>();
			int dist = 0;
			int minDist = 9999;
			try
			{
				TryMe tryme = new TryMe(this.routesArr, this.repeatCitiesAllowed);
				pathsArr.addAll(getPaths2(strOrigen, strDestination));
				
				for(int i=0;i<pathsArr.size();i++)
				{
					/*Finding the total distance of each path starting from A and ending at C*/
					dist = tryme.getDistance(pathsArr.get(i));
					System.out.println(pathsArr.get(i)+"=="+dist);
					/*Validating id this path has the shortest distance between from A and ending at C*/
					if(dist<minDist)
						minDist = dist;
				}
				if(minDist!=9999)
					System.out.println("==========>The length of the shortest route (in terms of distance to travel) from "+strOrigen+" to "+strDestination+":"+minDist);
				else
					System.out.println("==========>The length of the shortest route (in terms of distance to travel) from "+strOrigen+" to "+strDestination+": NO EXIST");
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getShortestDistRoute method:"+e.getMessage());
			}
			finally 
			{
				return minDist;
			}
		}
		
		public int getCountOfRoutesWithDistLessThanN(String strOrigen,String strDestination,int maxDist)
		{
			System.out.println("======= Evaluating the number of different routes from "+strOrigen+" to "+strDestination+" with a distance of less than 30 ======");
			ArrayList<String> pathsArr = new ArrayList<String>();
			ArrayList<String> pathsArr2 = new ArrayList<String>();
			int dist=0;
			int minDist = 0;
			try
			{
				TryMe tryme = new TryMe(this.routesArr, this.repeatCitiesAllowed);
				pathsArr.addAll(getPaths2(strOrigen, strDestination));
				pathsArr2.addAll(getPaths2(strDestination, strDestination));
				for(int i=0;i<pathsArr.size();i++)
				{
					/*Finding the total distance of each path starting from A and ending at C*/
					dist = tryme.getDistance(pathsArr.get(i));
					System.out.println(pathsArr.get(i)+"=="+dist);
					/*Validating id this path has distance <30*/
					if(dist<maxDist)
						minDist++;
				}
				if(this.repeatCitiesAllowed)
				{
					System.out.println("Considering route to repeated cities");
					for(int x=0;x<pathsArr.size();x++) //For each path from C-C
					{
						//System.out.println("x:"+x);
						for(int y=0;y<pathsArr2.size();y++) //For each path from C-C
						{
							//System.out.println("  y:"+y);
							dist = tryme.getDistance((pathsArr.get(x).concat(pathsArr2.get(y).substring(1))));//Validate if adding the path still obeys the condition (distance<30).
							if(dist<maxDist)
							{
								//System.out.println("inside for["+x+"]["+y+"]:"+(pathsArr.get(x).length()+pathsArrCC.get(y).length()));
								pathsArr.add(pathsArr.get(x).concat(pathsArr2.get(y).substring(1)));
								System.out.println(pathsArr.get(x).concat(pathsArr2.get(y).substring(1))+"=="+dist);
								minDist++;
							}
						}						
					}
				}
				if(minDist!=0)
					System.out.println("==========>The number of different routes from C to C with a distance of less than 30:"+minDist);
				else
					System.out.println("==========>The number of different routes from C to C with a distance of less than 30: NO EXIST");
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured in getCountOfRoutesWithDistLessThanN method:"+e.getMessage());
			}
			finally 
			{
				return minDist;
			}
		}

}
