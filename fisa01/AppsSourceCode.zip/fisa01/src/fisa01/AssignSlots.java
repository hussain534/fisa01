package fisa01;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;

public class AssignSlots
{
	public static void main(String[] args)
	{
		System.out.println("*****************************************************************");
		System.out.println("This application will assign slots.");
		System.out.println("*****************************************************************");
		try
		{
			Date date = Calendar.getInstance().getTime();  
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
            String strDate = dateFormat.format(date);  
            //System.out.println("Current date: " + strDate); 
            
            Date d1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(strDate.concat(" 09:00:00"));  
            //System.out.println(strDate+"\t"+d1); 
            
            DateFormat dateFormatTime = new SimpleDateFormat("HH:mmaa");
            
		
			ArrayList<String> sessionArr = new ArrayList<String>();
			ArrayList<String> sessionDurationArr = new ArrayList<String>();
			ArrayList<String> sessionDurationTempArr = new ArrayList<String>();
			
			int slots[]= {180,180,180,180,60,60};
			
			ArrayList<String> track1MorningArr = new ArrayList<String>();
			ArrayList<String> track1EveningArr = new ArrayList<String>();
			ArrayList<String> track1BeforenetworkingEventArr = new ArrayList<String>();
	
			ArrayList<String> track2MorningArr = new ArrayList<String>();
			ArrayList<String> track2EveningArr = new ArrayList<String>();
			ArrayList<String> track2BeforenetworkingEventArr = new ArrayList<String>();
			
			ArrayList<String> resultTrack1Arr = new ArrayList<String>();
			ArrayList<String> resultTrack2Arr = new ArrayList<String>();
			
			
			sessionArr.add("Writing Fast Tests Against Enterprise Rails");
			sessionArr.add("Overdoing it in Python");
			sessionArr.add("Lua for the Masses");
			sessionArr.add("Ruby Errors from Mismatched Gem Versions");
			sessionArr.add("Common Ruby Errors");
			sessionArr.add("Rails for Python Developers");
			sessionArr.add("Communicating Over Distance");
			sessionArr.add("Accounting-Driven Development");
			sessionArr.add("Woah");
			sessionArr.add("Sit Down and Write");
			sessionArr.add("Pair Programming vs Noise");
			sessionArr.add("Rails Magic");
			sessionArr.add("Ruby on Rails: Why We Should Move On");
			sessionArr.add("Clojure Ate Scala");
			sessionArr.add("Programming in the Boondocks of Seattle");
			sessionArr.add("Ruby vs. Clojure for Back-End Development");
			sessionArr.add("Ruby on Rails Legacy App Maintenance");
			sessionArr.add("A World Without HackerNews");
			sessionArr.add("User Interface CSS in Rails Apps");
			
			sessionDurationArr.add("60");
			sessionDurationArr.add("45");
			sessionDurationArr.add("30");
			sessionDurationArr.add("45");
			sessionDurationArr.add("45");
			sessionDurationArr.add("05");
			sessionDurationArr.add("60");
			sessionDurationArr.add("45");
			sessionDurationArr.add("30");
			sessionDurationArr.add("30");
			sessionDurationArr.add("45");
			sessionDurationArr.add("60");
			sessionDurationArr.add("60");
			sessionDurationArr.add("45");
			sessionDurationArr.add("30");
			sessionDurationArr.add("30");
			sessionDurationArr.add("60");
			sessionDurationArr.add("30");
			sessionDurationArr.add("30");
			
			System.out.println("INPUTS ARE:");
			for(int x=0;x<sessionDurationArr.size();x++)
			{
				System.out.println(sessionArr.get(x).concat(" ").concat(sessionDurationArr.get(x)).concat(" min"));
			}
			
			for(int x=0;x<sessionDurationArr.size();x++)
			{
				sessionDurationTempArr.add(sessionDurationArr.get(x).concat("~").concat(sessionArr.get(x)));
			}
			
			Collections.sort(sessionDurationTempArr, Collections.reverseOrder());
			//Collections.sort(sessionDurationTempArr);
			
			
			
			
			System.out.println("=======PRINTING sessionDurationTempArr START=====");
			for(int x=0;x<sessionDurationTempArr.size();x++)
			{
				System.out.println(sessionDurationTempArr.get(x));
			}
			System.out.println("=======PRINTING sessionDurationTempArr END=====");
	
			
			for(int x=0;x<sessionDurationTempArr.size();x++)
			{
				sessionDurationArr.set(x, sessionDurationTempArr.get(x).split("~")[0]);
				sessionArr.set(x, sessionDurationTempArr.get(x).split("~")[1]);
			}
			
			
			
			
			System.out.println("Total sessions to assign:"+sessionDurationArr.size());
			int addMinutes=0;
			for(int t=0;t<sessionDurationArr.size();t++)
			{
				//System.out.println("t:"+t);
				for(int s=0;s<6;s++) //int slots[]= {180,180,180,180,60,60};
				{
					//System.out.println("s:"+s);
					if(slots[s]!=0 && ((slots[s]) % (Integer.parseInt(sessionDurationArr.get(t)))==0))
					{
						//System.out.println("Inside IF");
						slots[s]=slots[s]-Integer.parseInt(sessionDurationArr.get(t));
						if(s==0)
						{
							track1MorningArr.add(sessionDurationTempArr.get(t));
						}
						else if(s==1)
						{
							track1EveningArr.add(sessionDurationTempArr.get(t));
						}
						else if(s==2)
						{
							track2MorningArr.add(sessionDurationTempArr.get(t));
						}
						else if(s==3)
						{
							track2EveningArr.add(sessionDurationTempArr.get(t));
						}
						else if(s==4)
						{
							track1BeforenetworkingEventArr.add(sessionDurationTempArr.get(t));
						}
						else if(s==5)
						{
							track2BeforenetworkingEventArr.add(sessionDurationTempArr.get(t));
						}
						break;
					}
				}
			}
			resultTrack1Arr.addAll(track1MorningArr);
			resultTrack1Arr.add("60~Lunch");
			resultTrack1Arr.addAll(track1EveningArr);
			resultTrack1Arr.addAll(track1BeforenetworkingEventArr);
			resultTrack1Arr.add("00~Networking Event");
			
			Calendar cl = Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();
			Calendar cne = Calendar.getInstance();
			cl.setTime(d1);
			c2.setTime(d1);
			Date dne=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(strDate.concat(" 17:00:00"));
			cne.setTime(dne);
			
			System.out.println("========Track 1:");
			for(int t=0;t<resultTrack1Arr.size();t++)
			{
				cl.add(Calendar.MINUTE, addMinutes);
				if(resultTrack1Arr.get(t).split("~")[1].equalsIgnoreCase("Networking Event"))
				{
					while(cl.compareTo(cne)<0)
					{
						cl.add(Calendar.MINUTE, 5);
					}
				}
				strDate = dateFormatTime.format(cl.getTime());
				if(Integer.parseInt(resultTrack1Arr.get(t).split("~")[0])==5)
					System.out.println(strDate.concat(" ").concat(resultTrack1Arr.get(t).split("~")[1]).concat(" ").concat("lightning"));
				else if(resultTrack1Arr.get(t).split("~")[1].equalsIgnoreCase("Networking Event") || resultTrack1Arr.get(t).split("~")[1].equalsIgnoreCase("Lunch"))
					System.out.println(strDate.concat(" ").concat(resultTrack1Arr.get(t).split("~")[1]));
				else
					System.out.println(strDate.concat(" ").concat(resultTrack1Arr.get(t).split("~")[1]).concat(" ").concat(resultTrack1Arr.get(t).split("~")[0]).concat(" min"));
				
				addMinutes = Integer.parseInt(resultTrack1Arr.get(t).split("~")[0]);
			}
			
			resultTrack2Arr.addAll(track2MorningArr);
			resultTrack2Arr.add("60~Lunch");
			resultTrack2Arr.addAll(track2EveningArr);
			resultTrack2Arr.addAll(track2BeforenetworkingEventArr);
			resultTrack2Arr.add("00~Networking Event");
			
			
			
			System.out.println("========Track 2:");
			for(int t=0;t<resultTrack2Arr.size();t++)
			{
				c2.add(Calendar.MINUTE, addMinutes);
				
				if(resultTrack2Arr.get(t).split("~")[1].equalsIgnoreCase("Networking Event"))
				{
					while(c2.compareTo(cne)<0)
					{
						c2.add(Calendar.MINUTE, 5);
					}
				}
				strDate = dateFormatTime.format(c2.getTime());
				if(Integer.parseInt(resultTrack2Arr.get(t).split("~")[0])==5)
					System.out.println(strDate.concat(" ").concat(resultTrack2Arr.get(t).split("~")[1]).concat(" ").concat("lightning"));
				else if(resultTrack2Arr.get(t).split("~")[1].equalsIgnoreCase("Networking Event") || resultTrack2Arr.get(t).split("~")[1].equalsIgnoreCase("Lunch"))
					System.out.println(strDate.concat(" ").concat(resultTrack2Arr.get(t).split("~")[1]));				
				else
					System.out.println(strDate.concat(" ").concat(resultTrack2Arr.get(t).split("~")[1]).concat(" ").concat(resultTrack2Arr.get(t).split("~")[0]).concat(" min"));
				addMinutes = Integer.parseInt(resultTrack2Arr.get(t).split("~")[0]);
			}
			
			
			
			System.out.println();
		}
		catch (Exception e)
		{
			//System.out.println("Exception ::"+e.getMessage());
			e.printStackTrace();
		}
		
	}

}
