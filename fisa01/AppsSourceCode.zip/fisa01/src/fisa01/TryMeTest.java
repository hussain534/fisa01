package fisa01;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class TryMeTest 
{
	private ArrayList<String> routesArr = new ArrayList<String>();
	private boolean repeatCitiesAllowed;
	
	public TryMeTest()
	{
		this.routesArr.add("AB5");
		this.routesArr.add("BC4");
		this.routesArr.add("CD8");
		this.routesArr.add("DC8");
		this.routesArr.add("DE6");
		this.routesArr.add("AD5");
		this.routesArr.add("CE2");
		this.routesArr.add("EB3");
		this.routesArr.add("AE7");
		this.repeatCitiesAllowed = true;
		
		/*routesArr.add("AB3");
		this.routesArr.add("AD6");
		this.routesArr.add("AE1");
		this.routesArr.add("BC4");
		this.routesArr.add("CD5");
		this.routesArr.add("CE2");
		this.routesArr.add("DC6");
		this.routesArr.add("DE4");
		this.routesArr.add("EB2");
		this.routesArr.add("ED3");*/
		
		/*routesArr.add("AB2");
		this.routesArr.add("BC1");
		this.routesArr.add("CD3");
		this.routesArr.add("DE4");
		this.routesArr.add("EA3");
		this.routesArr.add("AC1");
		this.routesArr.add("EC2");*/
		
		/*routesArr.add("AB4");
		this.routesArr.add("AD5");
		this.routesArr.add("AE8");
		this.routesArr.add("BC5");
		this.routesArr.add("BD3");
		this.routesArr.add("BE10");
		this.routesArr.add("CA3");
		this.routesArr.add("CE5");
		this.routesArr.add("DC4");
		this.routesArr.add("ED6");*/
		
		/*routesArr.add("AB5");
		this.routesArr.add("BC4");
		this.routesArr.add("CD8");
		this.routesArr.add("DC8");
		this.routesArr.add("DE6");
		this.routesArr.add("AD5");
		this.routesArr.add("CE2");
		this.routesArr.add("EB3");
		this.routesArr.add("AE7");*/
	}

	@Test
	public void testInputData_InputOK() 
	{
		System.out.println("\ntestInputData_InputOK START");
		ArrayList<String> routesArr = new ArrayList<String>();
		boolean repeatCitiesAllowed = true;
		TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
		assertEquals("Input OK", tryme.validateInput("AB5"));
		System.out.println("testInputData_InputOK END\n");
	}
	
	@Test
	public void testInputData_DuplicateData() 
	{
		System.out.println("\ntestInputData_DuplicateData START");
		ArrayList<String> routesArr = new ArrayList<String>();
		boolean repeatCitiesAllowed = true;
		TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
		tryme.validateInput("AB5");
		assertEquals("Duplicate data for AB5.", tryme.validateInput("AB5"));
		System.out.println("testInputData_DuplicateData END\n");
	}
	
	@Test
	public void testInputData_InvalidOriginData() 
	{
		System.out.println("\ntestInputData_InvalidOriginData START");
		ArrayList<String> routesArr = new ArrayList<String>();
		boolean repeatCitiesAllowed = true;
		TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
		assertEquals("Input value FB5 for Origen town do not met the req.", tryme.validateInput("FB5"));	
		System.out.println("testInputData_InvalidOriginData END\n");
	}
	
	@Test
	public void testInputData_InvalidDestinationData() 
	{
		System.out.println("\ntestInputData_InvalidDestinationData START");
		ArrayList<String> routesArr = new ArrayList<String>();
		boolean repeatCitiesAllowed = true;
		TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
		assertEquals("Input value AZ5 for Destination town do not met the req.", tryme.validateInput("AZ5"));
		System.out.println("testInputData_InvalidDestinationData END\n");
	}
	
	@Test
	public void testInputData_InvalidDistanceData() 
	{
		System.out.println("\ntestInputData_InvalidDistanceData START");
		ArrayList<String> routesArr = new ArrayList<String>();
		boolean repeatCitiesAllowed = true;
		TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
		assertEquals("Input value AB0 for Distance do not met the req.", tryme.validateInput("AB0"));
		System.out.println("testInputData_InvalidDistanceData END\n");
	}
	
	@Test
	public void testInputData_InvalidData_OriginAndDestSame() 
	{
		System.out.println("\ntestInputData_InvalidData_OriginAndDestSame START");
		ArrayList<String> routesArr = new ArrayList<String>();
		boolean repeatCitiesAllowed = true;
		TryMe tryme = new TryMe(routesArr,repeatCitiesAllowed);
		assertEquals("Input value AA5 for Origen and Destination town cant be same.", tryme.validateInput("AA5"));
		System.out.println("testInputData_InvalidData_OriginAndDestSame END\n");
	}
	
	@Test
	public void testCond1() 
	{
		System.out.println("\ntestCond1 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(9, tryme.getDistance("ABC"));
		System.out.println("testCond1 END\n");
	}
	
	@Test
	public void testCond2() 
	{
		System.out.println("\ntestCond2 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(5, tryme.getDistance("AD"));
		System.out.println("testCond2 END\n");
	}
	
	@Test
	public void testCond3() 
	{
		System.out.println("\ntestCond3 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(13, tryme.getDistance("ADC"));
		System.out.println("testCond3 END\n");
	}
	
	@Test
	public void testCond4() 
	{
		System.out.println("\ntestCond4 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(22, tryme.getDistance("AEBCD"));
		System.out.println("testCond4 END\n");
	}
	
	@Test
	public void testCond5() 
	{
		System.out.println("\ntestCond5 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(0, tryme.getDistance("AED"));
		System.out.println("testCond5 END\n");
	}
	
	@Test
	public void testCond6() 
	{
		System.out.println("\ntestCond6 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(2, tryme.getTripsMaxNStops("C", "C", 3));
		System.out.println("testCond6 END\n");
	}
	
	@Test
	public void testCond7() 
	{
		System.out.println("\ntestCond7 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(3, tryme.getTripsExactNStops("A", "C", 4));
		System.out.println("testCond7 END\n");
	}
	
	@Test
	public void testCond8() 
	{
		System.out.println("\ntestCond8 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(9, tryme.getShortestDistRoute("A", "C"));
		System.out.println("testCond8 END\n");
	}
	
	@Test
	public void testCond9() 
	{
		System.out.println("\ntestCond9 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(9, tryme.getShortestDistRoute("B", "B"));
		System.out.println("testCond9 END\n");
	}
	
	@Test
	public void testCond10() 
	{
		System.out.println("\ntestCond10 START");
		new TryMeTest();
		TryMe tryme = new TryMe(this.routesArr,this.repeatCitiesAllowed);
		assertEquals(7, tryme.getCountOfRoutesWithDistLessThanN("C", "C", 30));
		System.out.println("testCond10 END\n");
	}
}
