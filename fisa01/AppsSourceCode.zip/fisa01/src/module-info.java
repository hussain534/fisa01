/**
 * 
 */
/**
 * @author EQUIPO 1
 *
 */
module com.trains {
	requires junit;
	exports fisa01;
}